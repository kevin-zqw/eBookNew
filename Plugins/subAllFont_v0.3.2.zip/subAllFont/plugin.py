#部分代码参考或者搬运于Doitsu的SubsetFontssigil插件

import cssutils
from fontTools import subset
from fontTools.ttLib import TTFont
import os
import re
import html
try:
    from sigil_bs4 import BeautifulSoup as BS
except:
    from bs4 import BeautifulSoup as BS


pattern = r'\.\./Fonts/([-\w._]+)'
prog = re.compile(pattern)
def getUsedFonts(content):
    font_name = ""
    match = prog.search(content)
    if(match!=None):
        font_name=match.group(1)
    return font_name

def addFontFamilyToInfo(font_info,font_family_info,font_name,font_family):
    #确保css字体声明中的字体文件名有对应的字体文件
    if(font_name in font_info):
        if(font_info[font_name]==None):
            font_info[font_name]={}
            font_info[font_name]["selector"]=[]
            font_info[font_name]["chars"]=set()
        font_family_info[font_family]=font_name
    else:
        print("字体{}在Fonts文件夹中不存在".format(font_name))

def addSelectorToInfo(font_info,font_name,selector_list):
    if(font_name!=""):
        for selector in selector_list:
            if(not selector in font_info[font_name]["selector"]):
                font_info[font_name]["selector"].append(selector.selectorText)

def getFontInfoFromCSS(css_content, font_files):
    font_info={}
    font_family_info={}

    for font_name in font_files:
        font_info[font_name]=None

    sheet = cssutils.parseString(css_content)
    for rule in sheet:
        if rule.type == rule.FONT_FACE_RULE:
            font_family=""
            for property in rule.style:
                if(property.name=="font-family"):
                    font_family=property.value
                if(property.name=="src"):
                    print(property.value)
                    font_name=getUsedFonts(property.value)
                    if(font_name!=""):
                        addFontFamilyToInfo(font_info,font_family_info,font_name,font_family)
                    else:
                        print("无法找到{}字体相关url信息".format(font_family))
    for rule in sheet:
        if rule.type == rule.STYLE_RULE:
            font_family=""
            for property in rule.style:
                if(property.name=="font-family"):
                    value_list=property.value.split(",")
                    for value in value_list:
                        font_family=value.strip()
                        if(font_family in font_family_info):
                            #当字体声明的字体的url缺失或者引用的字体在Fonts文件夹下不存在时
                            #font_family_info不会存放相关font_family的信息
                            addSelectorToInfo(font_info, font_family_info.get(font_family,""), rule.selectorList)
    return font_info

def decode_xml_entities(s):
    def fix(m):
        c = m.group(1)
        # escape the escape sequences
        if (c == "amp"):
            return "&"
        if (c == "lt"):
            return "<"
        if (c == "gt"):
            return ">"
        if (c in html.entities.name2codepoint):
            # named entity
            return chr(html.entities.name2codepoint[c])
        else:
            # TODO this is ugly
            if ((c[0] == "#") and len(c) > 1):
                # numeric
                if ((c[1] == "x") and (len(c) > 2)):
                    try:
                        i = int(c[2:], 16)
                        return chr(i)
                    except:
                        # error
                        return ''
                else:
                    try:
                        i = int(c[1:])
                        return chr(i)
                    except:
                        # error
                        return ''
            # error!
            return ''

    return re.sub(r"&([#a-z0-9]+);", fix, s)

def getFontText(html, font_info):
    all_selector = []
    soup = BS(html, "html.parser")
    #body_node = soup.body
    for font_name in font_info.keys():
        if(font_info[font_name]==None):
            continue
        selector_list=font_info[font_name]["selector"]
        for selector in selector_list:
            nodes=soup.select(selector)
            text=""
            for node in nodes:
                text+=node.get_text()
            font_info[font_name]["chars"].update(decode_xml_entities(text))

def _subFont(font_path, subset_font_path, text):
    options = subset.Options()
    font = subset.load_font(font_path, options)

    subsetter = subset.Subsetter(options)
    subsetter.populate(text=text)

    subsetter.subset(font)
    subset.save_font(font, subset_font_path, options)
    font.close()

def subFont(font_path, subset_font_path, saved_char):
    font = TTFont(font_path)
    cmap=font["cmap"]
    #为了保证字体文件大小大于200K便于多看阅读器识别，强制保证字体字符数量在1500
    #add_times=1000-len(chars)
    #saved_char_num = len(saved_char)
    font_all_char = set()
    unicode_list=list(cmap.getBestCmap().keys())
    for uni in unicode_list:
        font_all_char.add(chr(uni))
    font_char_num = len(font_all_char)
    ture_saved_char = saved_char.intersection(font_all_char)
    true_saved_char_num = len(ture_saved_char)

    original_font_size= os.path.getsize(font_path)
    external_text=""
    if(original_font_size*true_saved_char_num/font_char_num < 300*1024):
        rest_char=font_all_char - ture_saved_char
        end_index = int(300*1024*font_char_num/original_font_size - true_saved_char_num)
        #end_index=int(1000-1000*true_saved_char_num/font_char_num)
        external_text = "".join(rest_char)[-end_index:]
    text = "".join(ture_saved_char)+external_text
    print("子集化共保存{}个字符(原本保留{}个字符，填充{}个字符)".format(len(text),
        true_saved_char_num,len(external_text)))
    _subFont(font_path, subset_font_path, text)

def printMessage(text):
    count = 45
    print("\n"+"="*count)
    print("\t"+text)
    print("="*count)

def run(bk):
    css_file_content=""
    font_files=[]
    printMessage("正获取css文件中相关字体信息")
    for css_id, href in bk.css_iter():
        css_file_name = href.split("/")[1]
        #print("正在处理{}文件".format(css_file_name),end="\r")
        css_file_content+=bk.readfile(css_id)
        #不能一个文件一个文件的解析，这样会导致有些字体会先读取字体声明，然后再读取字体设置，
        #导致字体路径忽略掉从而明明指明了字体路径而没有解析到
        #getFontMap(bk.readfile(css_id), font_map)
    for font_id,href,font_type in bk.font_iter():
        font_files.append(bk.href_to_basename(href))
    font_info=getFontInfoFromCSS(css_file_content, font_files)

    print(font_info)
    printMessage("正在获取字体所使用字符信息")

    for html_id, href in bk.text_iter():
        html_file_name = href.split("/")[1]
        #print("正在处理{}文件".format(html_file_name),end="\r")
        getFontText(bk.readfile(html_id),font_info)

    printMessage("正在精简字体（对于英文字体，只能精简，无法填充保证大小大于200K）")

    ebook_root = bk._w.ebook_root
    for font_name in font_info.keys():
        if(font_info[font_name]==None):
            continue
        #font_file_name= os.path.basename(font_map[font_name]["font_path"])

        original_font_path = os.path.join(ebook_root, 'OEBPS', 'Fonts', font_name)

        original_font_size = os.path.getsize(original_font_path)

        root, ext = os.path.splitext(font_name)
        subset_font_path = original_font_path.replace(ext, '.subset' + ext)
        
        #font_href = os.path.join("Fonts", font_file_name)

        print('\n正在处理字体： ', font_name+'...')
        print('原始字体文件大小： ',  original_font_size)

        #current_text = "".join(font_info[font_name]["chars"])
        #print("子集化保留字符({0}个)：{1}".format(len(current_text),current_text))
        chars=font_info[font_name]["chars"]
        char_count=len(chars)
        #print("子集化保留字符({0}个)".format(char_count))

        if(char_count==0):
            print("字体{}未被使用，跳过子集化".format(font_name))
            continue
        try:
            subFont(original_font_path,subset_font_path, chars)
            stderr =  b''
        except Exception as e:
            stderr = str(e)

        if stderr == b'':
            subset_font_size = os.path.getsize(subset_font_path)
            percentage = "({0:.2f}%)".format(subset_font_size/original_font_size*100)
            print("子集化后的字体文件大小:",subset_font_size,percentage)

            #only replace the font if it's smaller
            if subset_font_size < original_font_size:
                with open(subset_font_path,"rb") as f:
                    subset_font_data = f.read()
                try:
                    bk.writefile(bk.basename_to_id(font_name), subset_font_data)
                except Exception as e:
                    print(e)
                    return -1
                print('{}子集化成功！'.format(font_name))
            os.remove(subset_font_path)
        else:
            print("子集化失败："+stderr)
    return 0
    
def main():
    print('I reached main when I should not have\n')
    return -1

if __name__ == "__main__":
    sys.exit(main())